package mk.ukim.finki.wp.kol2023.g1.service;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Snacks;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;

import java.util.List;

public interface SnacksService {

    List<Snacks> listAllSnacks();

    Snacks findById(Long id);

    Snacks create(String name);

    Snacks update(Long id, String name);

    Snacks delete(Long id);
}
