package mk.ukim.finki.wp.kol2023.g1.service.impl;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.CustomCoffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidCustomCoffeeIdException;
import mk.ukim.finki.wp.kol2023.g1.repository.CustomRepository;
import mk.ukim.finki.wp.kol2023.g1.service.CustomService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomServiceImpl implements CustomService {

    private final CustomRepository customRepository;

    public CustomServiceImpl(CustomRepository customRepository) {
        this.customRepository = customRepository;
    }

    @Override
    public List<CustomCoffee> listAllCustomCoffees() {
        return this.customRepository.findAll();
    }

    @Override
    public CustomCoffee findById(Long id) {
        return this.customRepository.findById(id).orElseThrow(InvalidCustomCoffeeIdException::new);
    }

    @Override
    public CustomCoffee create(String name, Sugar sugar, Milk milk) {

        CustomCoffee customCoffee=new CustomCoffee(name, sugar, milk);
        return this.customRepository.save(customCoffee);
    }

    @Override
    public CustomCoffee update(Long id, String name, Sugar sugar, Milk milk) {

        CustomCoffee customCoffee=this.findById(id);
        customCoffee.setName(name);
        customCoffee.setSugar(sugar);
        customCoffee.setMilk(milk);

        return this.customRepository.save(customCoffee);
    }

    @Override
    public CustomCoffee delete(Long id) {

        CustomCoffee customCoffee = findById(id);
        this.customRepository.delete(customCoffee);
        return customCoffee;
    }
}
