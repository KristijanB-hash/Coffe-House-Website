package mk.ukim.finki.wp.kol2023.g1.config;

import mk.ukim.finki.wp.kol2023.g1.model.*;
import mk.ukim.finki.wp.kol2023.g1.service.CoffeeService;
import mk.ukim.finki.wp.kol2023.g1.service.CustomService;
import mk.ukim.finki.wp.kol2023.g1.service.SnacksService;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;


@Component
public class DataInitializer {


    private final SnacksService snacksService;
    private final CoffeeService coffeeService;
    private final CustomService customService;

    public DataInitializer(SnacksService snacksService, CoffeeService coffeeService, CustomService customService) {
        this.snacksService = snacksService;
        this.coffeeService = coffeeService;
        this.customService = customService;
    }

    public static List<Coffee> coffeeList = new ArrayList<>();
    public static List<Snacks> snacksList=new ArrayList<>();
    public static List<CustomCoffee> customCoffeeList=new ArrayList<>();
    public static List<ShoppingCart> shoppingCarts=new ArrayList<>();

    private Sugar randomizeSugar(int i) {
        if(i % 3 == 0) return Sugar.None;
        else if(i % 3 == 1) return Sugar.Little;
        return Sugar.Sweet;
    }

    private Milk randomizeMilk(int i) {
        if(i % 3 == 0) return Milk.Little;
        else if(i % 3 == 1) return Milk.Medium;
        return Milk.Alot;
    }

    @PostConstruct
    public void initData() {
        this.coffeeService.create("Cappuccino ", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Machiato", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Cold Brew", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Latte", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Americano", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Espresso", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Milkshake", Sugar.Little, Milk.Alot);
        this.coffeeService.create("Irish", Sugar.Little, Milk.Alot);


        this.snacksService.create("Cheesecake");
        this.snacksService.create("Panna cotta");
        this.snacksService.create("Tiramisu");
        this.snacksService.create("Lime pie");
        this.snacksService.create("Crepes");
        this.snacksService.create("Brownies");
        this.snacksService.create("Banana cake");
        this.snacksService.create("Carrot cake");



/*        for (int i = 1; i < 11; i++) {                                                                                  //ova e za custom coffees
            this.customService.create("Custom " + i, this.randomizeSugar(i), this.randomizeMilk(i));
        }*/
    }

/*    @PostConstruct
    public void initData() {
        for (int i = 1; i < 11; i++) {                                                                                  //ova e za obicni kafinja
            this.coffeeService.create("Coffee: " + i, this.randomizeSugar(i) , this.randomizeMilk(i));
        }

        for (int i = 1; i < 11; i++) {                                                                                  //ova e za custom coffees
            this.customService.create("Custom " + i, this.randomizeSugar(i), this.randomizeMilk(i));
        }
    }*/

}
