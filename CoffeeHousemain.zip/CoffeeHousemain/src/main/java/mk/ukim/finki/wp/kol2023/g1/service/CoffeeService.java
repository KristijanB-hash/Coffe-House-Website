package mk.ukim.finki.wp.kol2023.g1.service;

import mk.ukim.finki.wp.kol2023.g1.model.*;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidCoffeeIdException;

import java.util.List;

public interface CoffeeService {


    List<Coffee> listAllCoffees();

    Coffee findById(Long id);

    Coffee create(String name, Sugar sugar, Milk milk);

    Coffee update(Long id, String name, Sugar sugar, Milk milk);

    Coffee delete(Long id);
}
