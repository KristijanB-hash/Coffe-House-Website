package mk.ukim.finki.wp.kol2023.g1.service;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.CustomCoffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidCoffeeIdException;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidCustomCoffeeIdException;

import java.util.List;

public interface CustomService {


        List<CustomCoffee> listAllCustomCoffees();

        CustomCoffee findById(Long id);

        CustomCoffee create(String name, Sugar sugar, Milk milk);

        CustomCoffee update(Long id, String name, Sugar sugar, Milk milk);

        CustomCoffee delete(Long id);
}

