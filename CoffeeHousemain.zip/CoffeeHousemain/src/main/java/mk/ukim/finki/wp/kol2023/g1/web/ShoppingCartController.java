package mk.ukim.finki.wp.kol2023.g1.web;

import mk.ukim.finki.wp.kol2023.g1.model.ShoppingCart;
import mk.ukim.finki.wp.kol2023.g1.service.ShoppingCartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/shopping-cart")
public class ShoppingCartController {

    private final ShoppingCartService shoppingCartService;

    public ShoppingCartController(ShoppingCartService shoppingCartService) {
        this.shoppingCartService = shoppingCartService;
    }

    @GetMapping
    public String getShoppingCartPage(@RequestParam(required = false) String error,
                                      HttpServletRequest req,
                                      Model model) {
        if(error != null && !error.isEmpty()){
            model.addAttribute("hasError", true);
            model.addAttribute("error", error);
        }
        ShoppingCart shoppingCart = this.shoppingCartService.getActiveShoppingCart();
        model.addAttribute("coffeeList", this.shoppingCartService.listAllCoffeesInShoppingCart(shoppingCart.getId()));
        model.addAttribute("customCoffeeList", this.shoppingCartService.listAllCustomCoffeesInShoppingCart(shoppingCart.getId()));
        model.addAttribute("snacksList", this.shoppingCartService.listAllSnacksInShoppingCart(shoppingCart.getId()));

        System.out.println(this.shoppingCartService.listAllCoffeesInShoppingCart(shoppingCart.getId()));
        return "shopping-cart";
    }

    @DeleteMapping("/{cartId}/coffees")
    public ShoppingCart removeAllCoffeesFromShoppingCart(@PathVariable Long cartId, Model model) {

        model.addAttribute("cartId", cartId);
        return shoppingCartService.removeAllCoffeesFromShoppingCart(cartId);
    }

    @PostMapping("/add-coffee/{id}")
    public String addCoffeeToShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.addCoffeeToShoppingCart(id);
            return "redirect:/coffee";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }

    @PostMapping("/delete-coffee/{id}")
    public String deleteCoffeeFromShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.deleteCoffeeFromShoppingCart(id);
            return "redirect:/shopping-cart";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }

    @PostMapping("/add-custom-coffee/{id}")
    public String addCustomCoffeeToShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.addCustomCoffeeToShoppingCart(id);
            return "redirect:/customMenu";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }

    @PostMapping("/delete-custom-coffee/{id}")
    public String deleteCustomCoffeeFromShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.deleteCustomCoffeeFromShoppingCart(id);
            return "redirect:/shopping-cart";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }

    @PostMapping("/add-snack/{id}")
    public String addSnackToShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.addSnackToShoppingCart(id);
            return "redirect:/snacks";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }

    @PostMapping("/delete-snack/{id}")
    public String deleteSnackFromShoppingCart(@PathVariable Long id, HttpServletRequest req) {
        try{
            ShoppingCart shoppingCart=this.shoppingCartService.deleteSnackFromShoppingCart(id);
            return "redirect:/shopping-cart";
        }catch (RuntimeException exception) {
            return "redirect:/shopping-cart?error=" + exception.getMessage();
        }
    }
}

