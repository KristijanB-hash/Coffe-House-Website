package mk.ukim.finki.wp.kol2023.g1.service;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.CustomCoffee;
import mk.ukim.finki.wp.kol2023.g1.model.ShoppingCart;
import mk.ukim.finki.wp.kol2023.g1.model.Snacks;

import java.util.List;

public interface ShoppingCartService {

    List<Coffee> listAllCoffeesInShoppingCart(Long cartId);

   ShoppingCart removeAllCoffeesFromShoppingCart(Long cartId);

    List<CustomCoffee> listAllCustomCoffeesInShoppingCart(Long cartId);

    List<Snacks> listAllSnacksInShoppingCart(Long cartId);

    ShoppingCart getActiveShoppingCart();

    ShoppingCart addCoffeeToShoppingCart(Long coffeeId);

    ShoppingCart deleteCoffeeFromShoppingCart(Long coffeeId);

    ShoppingCart addCustomCoffeeToShoppingCart(Long customId);

    ShoppingCart deleteCustomCoffeeFromShoppingCart(Long customId);

    ShoppingCart addSnackToShoppingCart(Long snackId);

    ShoppingCart deleteSnackFromShoppingCart(Long customId);

}
