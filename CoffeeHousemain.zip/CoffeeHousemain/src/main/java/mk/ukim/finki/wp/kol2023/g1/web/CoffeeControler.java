package mk.ukim.finki.wp.kol2023.g1.web;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import mk.ukim.finki.wp.kol2023.g1.service.CoffeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class CoffeeControler {

    private final CoffeeService coffeeService;

    public CoffeeControler(CoffeeService coffeeService) {
        this.coffeeService = coffeeService;
    }

    /*
     * returns a list of all the coffee entities
     * returns the view list.html
     */

    @GetMapping( "/coffee")
    public String showPlayers(Model model) {

        List<Coffee> coffeeList;
        coffeeList=this.coffeeService.listAllCoffees();

        model.addAttribute("coffeeList", coffeeList);
        return "list";
    }

    /*
     * returns the view form.html
     */
    @GetMapping("/coffee/add")
    public String showAdd(Model model) {

        model.addAttribute("coffee", new Coffee());
        model.addAttribute("sugarAmmounts", Sugar.values());
        model.addAttribute("milkAmmounts", Milk.values());

        return "form";
    }

    /*
     * returns the view form.html
     */
    @GetMapping("/coffee/{id}/edit")
    public String showEdit(@PathVariable Long id, Model model) {


        model.addAttribute("coffee", coffeeService.findById(id));
        model.addAttribute("sugarAmmounts", Sugar.values());
        model.addAttribute("milkAmmounts", Milk.values());
        return "form";
    }

    /*
     * creates a new entity
     */
    @PostMapping("/coffee")
    public String create(
            @RequestParam String name,
            @RequestParam(required = false, defaultValue = "medium") Sugar sugar,
            @RequestParam(required = false, defaultValue = "medium") Milk milk) {

        this.coffeeService.create(name, sugar, milk);
        return "redirect:/coffee";
    }

    /*
     * updates an existing entity
     */
    @PostMapping("/coffee/{id}")
    public String update(
            @PathVariable Long id,
            @RequestParam String name,
            @RequestParam(required = false, defaultValue = "medium") Sugar sugar,
            @RequestParam(required = false, defaultValue = "medium") Milk milk) {

        this.coffeeService.update(id, name, sugar, milk);
        return "redirect:/coffee";
    }

    /*
     * deletes the entity
     */
    @PostMapping("/coffee/{id}/delete")
    public String delete(@PathVariable Long id) {
        this.coffeeService.delete(id);
        return "redirect:/coffee";
    }

}
