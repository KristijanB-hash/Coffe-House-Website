package mk.ukim.finki.wp.kol2023.g1.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
public class ShoppingCart {

    public ShoppingCart() {
        this.dateCreated = LocalDateTime.now();
        this.status = ShoppingCartStatus.CREATED;
        this.coffees = new ArrayList<>();
        this.customCoffees = new ArrayList<>();
        this.snacksList=new ArrayList<>();
    }

    @Id
    @GeneratedValue
    private Long id;

    private LocalDateTime dateCreated;

    @Enumerated(EnumType.STRING)
    private ShoppingCartStatus status;

    @ManyToMany
    private List<Coffee> coffees;

    @ManyToMany
    private List<CustomCoffee> customCoffees;

    @ManyToMany
    private List<Snacks> snacksList;

    public Long getId() {
        return id;
    }

    public LocalDateTime getDateCreated() {
        return dateCreated;
    }

    public ShoppingCartStatus getStatus() {
        return status;
    }

    public List<Coffee> getCoffees() {
        return coffees;
    }

    public List<CustomCoffee> getCustomCoffees() {
        return customCoffees;
    }

    public List<Snacks> getSnacksList() {
        return snacksList;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void setStatus(ShoppingCartStatus status) {
        this.status = status;
    }

    public void setCoffees(List<Coffee> coffees) {
        this.coffees = coffees;
    }

    public void setCustomCoffees(List<CustomCoffee> customCoffees) {
        this.customCoffees = customCoffees;
    }

    public void setSnacksList(List<Snacks> snacksList) {
        this.snacksList = snacksList;
    }
}
