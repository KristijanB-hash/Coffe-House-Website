package mk.ukim.finki.wp.kol2023.g1.service.impl;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.Snacks;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidSnackIdException;
import mk.ukim.finki.wp.kol2023.g1.repository.SnacksRepository;
import mk.ukim.finki.wp.kol2023.g1.service.SnacksService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SnacksServiceImpl implements SnacksService {

    private final SnacksRepository snacksRepository;

    public SnacksServiceImpl(SnacksRepository snacksRepository) {
        this.snacksRepository = snacksRepository;
    }

    @Override
    public List<Snacks> listAllSnacks() {
        return this.snacksRepository.findAll();
    }

    @Override
    public Snacks findById(Long id) {
        return this.snacksRepository.findById(id).orElseThrow(InvalidSnackIdException::new);
    }

    @Override
    public Snacks create(String name) {

        Snacks snacks= new Snacks(name);

        return this.snacksRepository.save(snacks);
    }

    @Override
    public Snacks update(Long id, String name) {

        Snacks snacks=this.findById(id);
        snacks.setName(name);

        return this.snacksRepository.save(snacks);
    }

    @Override
    public Snacks delete(Long id) {

        Snacks snacks=findById(id);
        this.snacksRepository.delete(snacks);
        return snacks;
    }
}
