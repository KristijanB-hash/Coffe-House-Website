package mk.ukim.finki.wp.kol2023.g1.model.exceptions;

public class InvalidCoffeeIdException extends RuntimeException{
}
