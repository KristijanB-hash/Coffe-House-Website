package mk.ukim.finki.wp.kol2023.g1.model;

import javax.persistence.*;

@Entity
public class CustomCoffee {

    public CustomCoffee() {
    }

    public CustomCoffee(String name, Sugar sugar, Milk milk) {
        this.name = name;
        this.sugar = sugar;
        this.milk = milk;
    }

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @Enumerated(EnumType.STRING)
    private Sugar sugar;

    @Enumerated(EnumType.STRING)
    private Milk milk;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Sugar getSugar() {
        return sugar;
    }

    public Milk getMilk() {
        return milk;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSugar(Sugar sugar) {
        this.sugar = sugar;
    }

    public void setMilk(Milk milk) {
        this.milk = milk;
    }

}
