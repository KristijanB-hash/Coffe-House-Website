package mk.ukim.finki.wp.kol2023.g1.model;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}
