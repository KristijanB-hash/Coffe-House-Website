package mk.ukim.finki.wp.kol2023.g1.web;

import mk.ukim.finki.wp.kol2023.g1.model.CustomCoffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping(value = {"/", "/home"})
public class HomeController {

    /*
     * returns the view home
     */
    @GetMapping
    public String showHomePage() {
        return "home";
    }
}
