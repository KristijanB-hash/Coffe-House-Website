package mk.ukim.finki.wp.kol2023.g1.service.impl;

import mk.ukim.finki.wp.kol2023.g1.model.*;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.ShoppingCartNotFoundException;
import mk.ukim.finki.wp.kol2023.g1.repository.ShoppingCartRepository;
import mk.ukim.finki.wp.kol2023.g1.service.CoffeeService;
import mk.ukim.finki.wp.kol2023.g1.service.CustomService;
import mk.ukim.finki.wp.kol2023.g1.service.ShoppingCartService;
import mk.ukim.finki.wp.kol2023.g1.service.SnacksService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {

    private final ShoppingCartRepository shoppingCartRepository;
    private final CoffeeService coffeeService;
    private final CustomService customService;
    private final SnacksService snacksService;

    public ShoppingCartServiceImpl(ShoppingCartRepository shoppingCartRepository, CoffeeService coffeeService, CustomService customService, SnacksService snacksService) {
        this.shoppingCartRepository = shoppingCartRepository;
        this.coffeeService = coffeeService;
        this.customService = customService;
        this.snacksService = snacksService;
    }

    @Override
    public List<Coffee> listAllCoffeesInShoppingCart(Long cartId) {
        if(!this.shoppingCartRepository.findById(cartId).isPresent())
            throw new ShoppingCartNotFoundException(cartId);
        return this.shoppingCartRepository.findById(cartId).get().getCoffees();      //se vrakjaat site kafinja vo edna kosnicka
    }

    @Override
    public ShoppingCart removeAllCoffeesFromShoppingCart(Long cartId) {
        ShoppingCart shoppingCart = this.shoppingCartRepository.findById(cartId)
                .orElseThrow(() -> new ShoppingCartNotFoundException(cartId));

        shoppingCart.getCoffees().clear();
        return this.shoppingCartRepository.save(shoppingCart);
    }


    @Override
    public List<CustomCoffee> listAllCustomCoffeesInShoppingCart(Long cartId) {
        if(!this.shoppingCartRepository.findById(cartId).isPresent())
            throw new ShoppingCartNotFoundException(cartId);
        return this.shoppingCartRepository.findById(cartId).get().getCustomCoffees();
    }

    @Override
    public List<Snacks> listAllSnacksInShoppingCart(Long cartId) {
        if(!this.shoppingCartRepository.findById(cartId).isPresent())
            throw new ShoppingCartNotFoundException(cartId);
        return this.shoppingCartRepository.findById(cartId).get().getSnacksList();
    }

    @Override
    public ShoppingCart getActiveShoppingCart() {

        return this.shoppingCartRepository
                .findByStatus(ShoppingCartStatus.CREATED)
                .orElseGet(() -> {
                    ShoppingCart shoppingCart = new ShoppingCart();
                    return this.shoppingCartRepository.save(shoppingCart);
                });
    }

    @Override
    public ShoppingCart addCoffeeToShoppingCart(Long coffeeId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();             //prvin gledame dali ima aktivna kosnicka
        Coffee coffee=this.coffeeService.findById(coffeeId);

        shoppingCart.getCoffees().add(coffee);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart deleteCoffeeFromShoppingCart(Long coffeeId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();
        Coffee coffee=this.coffeeService.findById(coffeeId);

        shoppingCart.getCoffees().remove(coffee);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart addCustomCoffeeToShoppingCart(Long customId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();
        CustomCoffee customCoffee=this.customService.findById(customId);

        shoppingCart.getCustomCoffees().add(customCoffee);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart deleteCustomCoffeeFromShoppingCart(Long customId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();
        CustomCoffee customCoffee=this.customService.findById(customId);

        shoppingCart.getCustomCoffees().remove(customCoffee);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart addSnackToShoppingCart(Long snackId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();
        Snacks snack=this.snacksService.findById(snackId);

        shoppingCart.getSnacksList().add(snack);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public ShoppingCart deleteSnackFromShoppingCart(Long snackId) {
        ShoppingCart shoppingCart=this.getActiveShoppingCart();
        Snacks snack=this.snacksService.findById(snackId);

        shoppingCart.getSnacksList().remove(snack);
        return this.shoppingCartRepository.save(shoppingCart);
    }
}
