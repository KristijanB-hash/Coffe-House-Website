package mk.ukim.finki.wp.kol2023.g1.service.impl;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.CustomCoffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import mk.ukim.finki.wp.kol2023.g1.model.exceptions.InvalidCoffeeIdException;
import mk.ukim.finki.wp.kol2023.g1.repository.CoffeRepository;
import mk.ukim.finki.wp.kol2023.g1.service.CoffeeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoffeeServiceImpl implements CoffeeService {

    private final CoffeRepository coffeRepository;

    public CoffeeServiceImpl(CoffeRepository coffeRepository) {
        this.coffeRepository = coffeRepository;
    }

    @Override
    public List<Coffee> listAllCoffees() {
        return this.coffeRepository.findAll();
    }

    @Override
    public Coffee findById(Long id) {
        return this.coffeRepository.findById(id).orElseThrow(InvalidCoffeeIdException::new);
    }

    @Override
    public Coffee create(String name, Sugar sugar, Milk milk) {

        Coffee coffee=new Coffee(name, sugar, milk);

        return this.coffeRepository.save(coffee);
    }

    @Override
    public Coffee update(Long id, String name, Sugar sugar, Milk milk) {

        Coffee coffee=this.findById(id);
        coffee.setName(name);
        coffee.setSugar(sugar);
        coffee.setMilk(milk);

        return this.coffeRepository.save(coffee);
    }

    @Override
    public Coffee delete(Long id) {

        Coffee coffee = findById(id);
        this.coffeRepository.delete(coffee);
        return coffee;
    }
}
