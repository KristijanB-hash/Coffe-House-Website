package mk.ukim.finki.wp.kol2023.g1.web;


import mk.ukim.finki.wp.kol2023.g1.model.*;
import mk.ukim.finki.wp.kol2023.g1.service.CustomService;
import mk.ukim.finki.wp.kol2023.g1.service.FilesStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class CustomCoffeeController {

    private final CustomService customService;

    public CustomCoffeeController(CustomService customService) {
        this.customService = customService;
    }

    @Autowired
    FilesStorageService storageService;

    /*
     * returns a list of all the custom created coffee entities
     * returns the view customMenu.html
     */

    @GetMapping(value = {"/customMenu"})
    public String showCustomCoffees(Model model) {

        List<CustomCoffee> customCoffeeList;
        customCoffeeList=this.customService.listAllCustomCoffees();



        List<ImageInfo> imageInfos = storageService.loadAll().map(path -> {
            String filename = path.getFileName().toString();
            String url = MvcUriComponentsBuilder
                    .fromMethodName(ImageController.class, "getImage", path.getFileName().toString()).build().toString();

            return new ImageInfo(filename, url);
        }).collect(Collectors.toList());

        model.addAttribute("images", imageInfos);

        model.addAttribute("customCoffeeList", customCoffeeList);
        return "customMenu.html";
    }


    /*
     * returns the view customCoffeeForm.html
     */
    @GetMapping("/customMenu/add")
    public String showAdd(Model model) {

        model.addAttribute("custom", new CustomCoffee());
        model.addAttribute("sugarAmmounts", Sugar.values());
        model.addAttribute("milkAmmounts", Milk.values());

        return "customCoffeeForm";
    }

    /*
     * returns the view customCoffeeForm.html
     */
    @GetMapping("/customMenu/{id}/edit")
    public String showEdit(@PathVariable Long id, Model model) {

        model.addAttribute("custom", customService.findById(id));
        model.addAttribute("sugarAmmounts", Sugar.values());
        model.addAttribute("milkAmmounts", Milk.values());
        return "customCoffeeForm";
    }

    /*
     * creates a new entity
     */
    @PostMapping("/customMenu")
    public String create(
            @RequestParam String name,
            @RequestParam(required = false, defaultValue = "medium") Sugar sugar,
            @RequestParam(required = false, defaultValue = "medium") Milk milk) {

        this.customService.create(name, sugar, milk);
        return "redirect:/customMenu";
    }

    /*
     * updates an existing entity
     */
    @PostMapping("/customMenu/{id}")
    public String update(
            @PathVariable Long id,
            @RequestParam String name,
            @RequestParam(required = false, defaultValue = "medium") Sugar sugar,
            @RequestParam(required = false, defaultValue = "medium") Milk milk) {

        this.customService.update(id, name, sugar, milk);
        return "redirect:/customMenu";
    }

    /*
     * deletes the entity
     */
    @PostMapping("/customMenu/{id}/delete")
    public String delete(@PathVariable Long id, Model model) {
        this.customService.delete(id);
        return "redirect:/customMenu";
    }
}
