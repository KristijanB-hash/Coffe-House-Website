package mk.ukim.finki.wp.kol2023.g1.repository;

import mk.ukim.finki.wp.kol2023.g1.config.DataInitializer;
import mk.ukim.finki.wp.kol2023.g1.model.ShoppingCart;
import mk.ukim.finki.wp.kol2023.g1.model.ShoppingCartStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ShoppingCartRepository extends JpaRepository<ShoppingCart, Long> {

/*     Optional<ShoppingCart> findByStatus(ShoppingCartStatus status){
        return DataInitializer.shoppingCarts.stream()
                .filter(i->i.getStatus().equals(status))
                .findFirst();
    }*/

    Optional<ShoppingCart> findByStatus(ShoppingCartStatus status);

}
