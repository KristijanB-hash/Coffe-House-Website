package mk.ukim.finki.wp.kol2023.g1.web;

import mk.ukim.finki.wp.kol2023.g1.model.Coffee;
import mk.ukim.finki.wp.kol2023.g1.model.Milk;
import mk.ukim.finki.wp.kol2023.g1.model.Snacks;
import mk.ukim.finki.wp.kol2023.g1.model.Sugar;
import mk.ukim.finki.wp.kol2023.g1.service.SnacksService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SnacksController {

    private final SnacksService snacksService;

    public SnacksController(SnacksService snacksService) {
        this.snacksService = snacksService;
    }

    @GetMapping( "/snacks")
    public String showSnacks(Model model) {

        List<Snacks> snacksList;
        snacksList=this.snacksService.listAllSnacks();


        model.addAttribute("snacksList", snacksList);
        return "Snacks";
    }


    @GetMapping("/snacks/add")
    public String showAdd(Model model) {


        model.addAttribute("snacks", new Coffee());

        return "snacks_form";
    }


    @GetMapping("/snacks/{id}/edit")
    public String showEdit(@PathVariable Long id, Model model) {


        model.addAttribute("snacks", snacksService.findById(id));

        return "snacks_form";
    }


    @PostMapping("/snacks")
    public String create(@RequestParam String name) {

        this.snacksService.create(name);
        return "redirect:/snacks";
    }


    @PostMapping("/snacks/{id}")
    public String update(
            @PathVariable Long id,
            @RequestParam String name) {

        this.snacksService.update(id, name);
        return "redirect:/snacks";
    }


    @PostMapping("/snacks/{id}/delete")
    public String delete(@PathVariable Long id) {

        this.snacksService.delete(id);
        return "redirect:/snacks";
    }

}
